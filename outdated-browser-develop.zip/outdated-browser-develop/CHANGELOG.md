
# Outdated Browser — Changelog

## v1.1.3
Date: 2016-03-07

 * New naming system for language files using the IETF language tags.
 * Changed urls to http://outdatedbrowser.com according to the new language naming system

## v1.1.2
Date: 2015-09-10

 * @alexprg: Add Traditional Chinese

## v1.1.1
Date: 2015-08-21

 * @alexprg: Bower support
 * @alexprg: New languages


## v1.1.0
Date: 2014-08-05

 * @alexprg: Support Languages
 * @alexprg: Ajax and no Ajax Support


## v1.0.2
Date: 2014-07-03

 * @alexprg: Inline colors for all elements (override page styles)
 * @alexprg: /demo - jquery demo, more info how to use
 * @alexprg: update instructions & link for notice image

<br><br>
[Bürocratik](http://burocratik.com)
